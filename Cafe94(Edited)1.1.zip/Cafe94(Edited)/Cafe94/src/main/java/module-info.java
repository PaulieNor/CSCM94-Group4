module cscm12.cafe94 {
    requires javafx.graphics;
    requires javafx.fxml;
    requires javafx.controls;
    requires java.sql;
    requires mysql.connector.java;
    requires java.desktop;
    opens cscm12.cafe94 to javafx.fxml;
    exports cscm12.cafe94;
}