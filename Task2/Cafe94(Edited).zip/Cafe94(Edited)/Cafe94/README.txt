[FILES]------------------------------------
- Main.java
- Controller.java
- ManageStaff.java

- Manager.fxml
- ManageStaff.fxml
- StaffLogin.fxml

- module-info.java
- managestaff.sql
- mysql-connector-java-8.0.28

[LOCATIONS]--------------------------------
Main .JAVAfiles:
Cafe94\src\main\java\cscm12\cafe94

Main .FXML files:
Cafe94\src\main\resources\cscm12\cafe94

Database, SQL connector, Module info:
Cafe94\src\main\java

Other files (JDK generated):
Cafe94\target\classes\cscm12\cafe94
Cafe94\target\classes

^ Names for these are the same as .java and .fxml's.