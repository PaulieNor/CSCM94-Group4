package cscm12.cafe94;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.Objects;

public class Waiters {







    public void serveFood(){
        //find oldest order that is both complete and marked for table service
        //mark as served
    }
    public void getBooking(){
        //set chosen table to booked so that it cannot be selected
    }
}
// link to staff login
//add one waiter to staff for example
//serve food that has been completed and prepared and is marked for table service
//get booking method
//approve booking method for completing booking if there are suitable tables left
