package cscm12.cafe94;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;

public class RestaurantStaff {




}

// database of orders?
//methods to add and find current orders