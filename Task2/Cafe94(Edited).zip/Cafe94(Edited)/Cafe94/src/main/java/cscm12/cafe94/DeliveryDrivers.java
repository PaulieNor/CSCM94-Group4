package cscm12.cafe94;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.Objects;

public class DeliveryDrivers {



    public void deliverFood(){
        //find oldest order that is both complete and marked for delivery
        //mark as served
    }
}
// link to staff login
//add one driver to staff for example
//deliver food that is prepared, completed and marked for delivery
